﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GXPEngine;

public class GameSettings : Level
{
    public GameSettings() : base("Settings"/*, name + "Background.png"*/)
    {
        //
    }
}
